import { Avatar } from "@mui/material";

function AvatarMUI({ src }) {

    return (
        <Avatar>
            {/*{src ? <img src={src} /> : <img src={kuvat / rr1.jpg'} />} alt = 'AM' >*/}

        </ Avatar >
    )
}


export default AvatarMUI;